﻿using UnityEngine;
using System.Collections;

//public class LoginModel 
//{
//   public string userName;
//    public string password;
//    public string logintime;
//}


//public class GameScoreModel
//{
//    public string userName;
//    public int score;
//    public int missenemy;
//}
