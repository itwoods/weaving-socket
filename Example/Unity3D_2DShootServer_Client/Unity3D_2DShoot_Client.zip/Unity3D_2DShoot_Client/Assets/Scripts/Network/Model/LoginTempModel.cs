﻿using System;


namespace MyTcpCommandLibrary.Model
{

    public class LoginTempModel
    {
        public string userName;
        public string password;
        public string logintime;
    }
}
