﻿using System;


namespace MyTcpCommandLibrary.Model
{

    public class GameScoreTempModel
    {
        public string userName;
        public int score;
        public int missenemy;
    }

}
