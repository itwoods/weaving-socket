﻿using System;



public interface ICheckServerMessage
{

    void CheckServerMessage( string text);

}

