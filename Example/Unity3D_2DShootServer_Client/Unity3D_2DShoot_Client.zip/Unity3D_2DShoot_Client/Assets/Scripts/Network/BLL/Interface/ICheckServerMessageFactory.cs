﻿using System;

public interface ICheckServerMessageFactory
{

    ICheckServerMessage CheckServerMessage();
   
}
