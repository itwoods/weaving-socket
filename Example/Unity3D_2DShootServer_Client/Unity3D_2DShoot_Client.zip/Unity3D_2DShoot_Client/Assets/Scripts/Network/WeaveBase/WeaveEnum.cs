﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace WeaveBase
{
    public enum WeavePortTypeEnum { Web,     Json,   Bytes,  Http }
    public enum WeaveDataTypeEnum { Json, Bytes };
    public enum WeavePipelineTypeEnum { ten=10, hundred=100, thousand=1000, ten_thousand=10000 };
}
